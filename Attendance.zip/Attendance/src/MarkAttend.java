import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class MarkAttend extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MarkAttend frame = new MarkAttend();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MarkAttend() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 638, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		String cids[]=new String[] {"P","A","NA"};
		JLabel lblSt = new JLabel("ST");
		lblSt.setBounds(23, 80, 24, 19);
		contentPane.add(lblSt);
		//		String cids[]=new String[] {"B.Tech","MBA"};
		//JComboBox<String> cid = new JComboBox<String>(cids);
		//cid.setBounds(471, 224, 98, 22);
		//pane1.add(cid);
		JComboBox st = new JComboBox(cids);
		st.setBounds(76, 78, 64, 22);
		contentPane.add(st);
		
		JLabel lblOs = new JLabel("OS");
		lblOs.setBounds(23, 122, 24, 16);
		contentPane.add(lblOs);
		
		JLabel lblPy = new JLabel("Py");
		lblPy.setBounds(23, 169, 24, 16);
		contentPane.add(lblPy);
		
		JLabel lblFs = new JLabel("FS");
		lblFs.setBounds(299, 81, 24, 16);
		contentPane.add(lblFs);
		
		JLabel lblCr = new JLabel("Cr");
		lblCr.setBounds(299, 122, 24, 16);
		contentPane.add(lblCr);
		
		JLabel lblDm = new JLabel("DM");
		lblDm.setBounds(299, 169, 24, 16);
		contentPane.add(lblDm);
		
		JComboBox fs = new JComboBox(cids);
		fs.setBounds(413, 78, 64, 22);
		contentPane.add(fs);
		
		JComboBox os = new JComboBox(cids);
		os.setBounds(76, 119, 64, 22);
		contentPane.add(os);
		
		JComboBox cr = new JComboBox (cids);
		cr.setBounds(413, 119, 64, 22);
		contentPane.add(cr);
		
		JComboBox py = new JComboBox (cids);
		py.setBounds(76, 166, 64, 22);
		contentPane.add(py);
		
		JComboBox dm = new JComboBox (cids);
		dm.setBounds(413, 166, 64, 22);
		contentPane.add(dm);
		
		JLabel lblLab = new JLabel("Lab 1");
		lblLab.setBounds(23, 228, 31, 16);
		contentPane.add(lblLab);
		
		JComboBox l1 = new JComboBox (cids);
		l1.setBounds(76, 225, 49, 22);
		contentPane.add(l1);
		
		JLabel lblLab_1 = new JLabel("Lab 2");
		lblLab_1.setBounds(299, 228, 31, 16);
		contentPane.add(lblLab_1);
		
		JComboBox l2 = new JComboBox (cids);
		l2.setBounds(413, 225, 64, 22);
		contentPane.add(l2);
		String noc[]= new String[] {"1","2","3","4"};
		JComboBox stn = new JComboBox(noc);
		stn.setBounds(152, 78, 31, 22);
		contentPane.add(stn);
		
		JComboBox osn = new JComboBox(noc);
		osn.setBounds(152, 119, 31, 22);
		contentPane.add(osn);
		
		JComboBox pyn = new JComboBox(noc);
		pyn.setBounds(152, 166, 31, 22);
		contentPane.add(pyn);
		
		JComboBox l1n = new JComboBox(noc);
		l1n.setBounds(152, 225, 31, 22);
		contentPane.add(l1n);
		
		JComboBox fsn = new JComboBox(noc);
		fsn.setBounds(505, 78, 31, 22);
		contentPane.add(fsn);
		
		JComboBox crn = new JComboBox(noc);
		crn.setBounds(505, 119, 31, 22);
		contentPane.add(crn);
		
		JComboBox dmn = new JComboBox(noc);
		dmn.setBounds(505, 166, 31, 22);
		contentPane.add(dmn);
		
		JComboBox l2n = new JComboBox(noc);
		l2n.setBounds(505, 225, 31, 22);
		contentPane.add(l2n);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
                {	
                    float osc,stc,fsc,pyc,crc,dmc,l1c,l2c;
                    osc=0;stc=0;fsc=0;pyc=0;crc=0;dmc=0;l1c=0;l2c=0;
                    float osa,sta,fsa,pya,cra,dma,l1a,l2a;
                    osa=0;sta=0;fsa=0;pya=0;cra=0;dma=0;l1a=0;l2a=0;
                    float osat,stat,fsat,pyat,crat,dmat,l1at,l2at;
                    osat=0;stat=0;fsat=0;pyat=0;crat=0;dmat=0;l1at=0;l2at=0;
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance","root","");
                    String query="Select * from classes";
    				PreparedStatement ps=con.prepareStatement(query);
    				
    				ResultSet rs=ps.executeQuery();
    				if(rs.next())
    				{
    					osc=Integer.parseInt(rs.getString(1));
                    	dmc=Integer.parseInt(rs.getString(2));
                    	fsc=Integer.parseInt(rs.getString(3));
                    	stc=Integer.parseInt(rs.getString(4));
    					pyc=Integer.parseInt(rs.getString(5));
    					crc=Integer.parseInt(rs.getString(6));
    					l1c=Integer.parseInt(rs.getString(7));
    					l2c=Integer.parseInt(rs.getString(8));
    				}
    				String query2="Select * from attended";
    				PreparedStatement ps1=con.prepareStatement(query2);
    				
    				ResultSet rs1=ps1.executeQuery();
    				if(rs1.next())
    				{
    					osa=Integer.parseInt(rs1.getString(1));
                    	dma=Integer.parseInt(rs1.getString(2));
                    	fsa=Integer.parseInt(rs1.getString(3));
                    	sta=Integer.parseInt(rs1.getString(4));
    					pya=Integer.parseInt(rs1.getString(5));
    					cra=Integer.parseInt(rs1.getString(6));
    					l1a=Integer.parseInt(rs1.getString(7));
    					l2a=Integer.parseInt(rs1.getString(8));
    				}
                    if(os.getSelectedItem()=="P")
                    {	
                    	int osnn=Integer.parseInt((String) osn.getSelectedItem());
                    	osc=osc+osnn;
                    	osa=osa+osnn;
                    	osat=(osa/osc)*100;
                    	
                    }
                    if(os.getSelectedItem()=="A")
                    {	int osnn=Integer.parseInt((String) osn.getSelectedItem());
                    	osc=osc+osnn;
                    	osat=(osa/osc)*100;
                    }
                    if(os.getSelectedItem()=="NA") 
                    {		int osnn=Integer.parseInt((String) osn.getSelectedItem());
                    		osat=(osa/osc)*100;
                    }
                    if(dm.getSelectedItem()=="P")
                    {	int dmnn=Integer.parseInt((String) dmn.getSelectedItem());
                    	dmc=dmc+dmnn;
                    	dma=dma+dmnn;
                    	dmat=(dma/dmc)*100;
                    }
                    if(dm.getSelectedItem()=="A")
                    {	int dmnn=Integer.parseInt((String) dmn.getSelectedItem());
                    	dmc=dmc+dmnn;
                    	dmat=(dma/dmc)*100;
                    }
                    if(dm.getSelectedItem()=="NA") 
                    {		
                    		dmat=(dma/dmc)*100;
                    }
                    if(fs.getSelectedItem()=="P")
                    {
                    	int fsnn=Integer.parseInt((String) fsn.getSelectedItem());
                    	fsc=fsc+fsnn;
                    	fsa=fsa+fsnn;
                    	fsat=(fsa/fsc)*100;
                    }
                    if(fs.getSelectedItem()=="A")
                    {
                    	int fsnn=Integer.parseInt((String) fsn.getSelectedItem());
                    	fsc=fsc+fsnn;
                    	
                    	fsat=(fsa/fsc)*100;
                    }
                    if(fs.getSelectedItem()=="NA") 
                    {
                    		fsat=(fsa/fsc)*100;
                    }
                    if(st.getSelectedItem()=="P")
                    {int stnn=Integer.parseInt((String) stn.getSelectedItem());
                	stc=stc+stnn;
                	sta=sta+stnn;
                    	stat=(sta/stc)*100;
                    }
                    if(st.getSelectedItem()=="A")
                    {
                    	int stnn=Integer.parseInt((String) stn.getSelectedItem());
                    	stc=stc+stnn;
                    	stat=(sta/stc)*100;
                    }
                    if(st.getSelectedItem()=="NA") 
                    {
                    		stat=(sta/stc)*100;
                    }
                    if(py.getSelectedItem()=="P")
                    {
                    	int pynn=Integer.parseInt((String) pyn.getSelectedItem());
                    	pyc=pyc+pynn;
                    	pya=pya+pynn;
                    	pyat=(pya/pyc)*100;
                    }
                    if(py.getSelectedItem()=="A")
                    {	int pynn=Integer.parseInt((String) pyn.getSelectedItem());
                    	pyc=pyc+pynn;
                    	pyat=(pya/pyc)*100;
                    }
                    if(py.getSelectedItem()=="NA") 
                    {	
                    	pyat=(pya/pyc)*100;
                    }
                    if(cr.getSelectedItem()=="P")
                    {
                    	int crnn=Integer.parseInt((String) crn.getSelectedItem());
                    	crc=crc+crnn;
                    	cra=cra+crnn;
                    	crat=(cra/crc)*100;
                    }
                    if(cr.getSelectedItem()=="A")
                    {
                    	int crnn=Integer.parseInt((String) crn.getSelectedItem());
                    	crc=crc+crnn;
                    	crat=(cra/crc)*100;
                    }
                    if(cr.getSelectedItem()=="NA") 
                    {
                    	crat=(cra/crc)*100;
                    }
                    if(l1.getSelectedItem()=="P")
                    {
                    	int l1nn=Integer.parseInt((String) l1n.getSelectedItem());
                    	l1c=l1c+l1nn;
                    	l1a=l1a+l1nn;
                    	l1at=(l1a/l1c)*100;
                    }
                    if(l1.getSelectedItem()=="A")
                    {
                    	int l1nn=Integer.parseInt((String) l1n.getSelectedItem());
                    	l1c=l1c+l1nn;
                    	l1at=(l1a/l1c)*100;
                    }
                    if(l1.getSelectedItem()=="NA") 
                    {
                    		l1at=(l1a/l1c)*100;
                    }
                    if(l2.getSelectedItem()=="P")
                    {
                    	int l2nn=Integer.parseInt((String) l2n.getSelectedItem());
                    	l2c=l2c+l2nn;
                    	l2a=l2a+l2nn;
                    	l2at=(l2a/l2c)*100;
                    }
                    if(l2.getSelectedItem()=="A")
                    {
                    	int l2nn=Integer.parseInt((String) l2n.getSelectedItem());
                    	l2c=l2c+l2nn;
                    	l2at=(l2a/l2c)*100;
                    }
                    if(l2.getSelectedItem()=="NA") 
                    {
                    		l2at=(l2a/l2c)*100;
                    }
                    PreparedStatement ps2 = con.prepareStatement("INSERT INTO `att`(`USN`, `OS`, `DM`, `FS`, `ST`, `PY`, `CR`, `L1`, `L2`) VALUES (?,?,?,?,?,?,?,?,?)");
                    
                    ps2.setString(1,"1VA16IS057");
                    ps2.setInt(2,(int) osat);
                    ps2.setInt(3,(int) dmat);
                    ps2.setInt(4,(int) fsat);
                    ps2.setInt(5,(int) stat);
                    ps2.setInt(6,(int) pyat);
                    ps2.setInt(7,(int) crat);
                    ps2.setInt(8,(int) l1at);
                    ps2.setInt(9,(int) l2at);
                    ps2.execute();
                    
                    PreparedStatement ps3 = con.prepareStatement("UPDATE `attended` SET `os`=?,`dm`=?,`fs`=?,`st`=?,`py`=?,`cr`=?,`l1`=?,`l2`=? WHERE 1");
                    ps3.setInt(1,(int) osa);
                    ps3.setInt(2,(int) dma);
                    ps3.setInt(3,(int) fsa);
                    ps3.setInt(4,(int) sta);
                    ps3.setInt(5,(int) pya);
                    ps3.setInt(6,(int) cra);
                    ps3.setInt(7,(int) l1a);
                    ps3.setInt(8,(int) l2a);
                    ps3.executeUpdate();
                    
                    PreparedStatement ps4 = con.prepareStatement("UPDATE `classes` SET `OS`=?,`DM`=?,`FS`=?,`ST`=?,`Python`=?,`Crypt`=?,`FS Lab`=?,`ST Lab`=? WHERE 1");
                    ps4.setInt(1,(int) osc);
                    ps4.setInt(2,(int) dmc);
                    ps4.setInt(3,(int) fsc);
                    ps4.setInt(4,(int) stc);
                    ps4.setInt(5,(int) pyc);
                    ps4.setInt(6,(int) crc);
                    ps4.setInt(7,(int) l1c);
                    ps4.setInt(8,(int) l2c);
                    ps4.executeUpdate();
                 }
				catch(Exception e)
				{
					
				}
			}});
		
		
		btnSubmit.setBounds(152, 267, 97, 25);
		contentPane.add(btnSubmit);
		
	}
}
